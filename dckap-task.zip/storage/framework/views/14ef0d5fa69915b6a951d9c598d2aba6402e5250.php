<!DOCTYPE html>
<html>
   <head>
      <title>Shop Page</title>
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo e(url('/public/css/')); ?>/style.css">
      <link rel="stylesheet" type="text/css" href="<?php echo e(url('/public/css/')); ?>/tailwind.min.css">
   </head>
   <body>
      <section class="sec">
         <div class="container">
            <div class="row">
               <nav class="navbar navbar-expand-lg navbar-light bg-light">
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                     <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                           <a class="nav-link" href="<?=url('/');?>">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="<?=url('/cart');?>">Cart</a>
                        </li>                        
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </section>
      <section class="sec bg-light">
         <div class="container">
            <div class="row">
               <div class="col-sm-12 title_bx">
                  <h3 class="title"><?php echo e($moduleTitle); ?></h3>
               </div>
            </div>
         </div>
      </section>
      
      <section class="sec bg-light">
         <div class="container">
            <div class="row">
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-sm-4 title_bx">
                  <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data" class="">
                     <?php echo csrf_field(); ?>
                     <input type="hidden" value="<?php echo e($product_data['id']); ?>" name="id">
                     <input type="hidden" value="<?php echo e($product_data['name']); ?>" name="name">
                     <input type="hidden" value="<?php echo e($product_data['price']); ?>" name="price">
                     <input type="hidden" value="<?php echo e($product_data['image_name']); ?>"  name="image">
                     <div class="item">
                        <div class="sq_box shadow">
                           <div class="pdis_img"> 
                              <span class="wishlist">
                              <a alt="Add to Wish List" title="Add to Wish List" href="javascript:void(0);"> <i class="fa fa-heart"></i></a>
                              </span>
                              <a href="#">
                              <img src="<?php echo e(url('/public/images/products')); ?>/<?php echo e($product_data['image_name']); ?>"> 
                              </a>
                           </div>
                           <h4 class="mb-1"> <a href="details.php"><?php echo e($product_data['name']); ?></a> </h4>
                           <div class="price-box mb-2">
                              <span class="offer-price">Price <i class="fa fa-inr"></i> <?php echo e($product_data['price']); ?></span>
                           </div>
                           <div class="btn-box text-center">
                              <input type="number" value="1" name="quantity" style="width: 5em;border: 2px solid #000;border-radius: 10px;text-align: center;">
                              <button class="btn btn-sm">Add To Cart</button>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </section>
   </body>
</html><?php /**PATH D:\wamp64\www\dckap-task\resources\views/shop/index.blade.php ENDPATH**/ ?>